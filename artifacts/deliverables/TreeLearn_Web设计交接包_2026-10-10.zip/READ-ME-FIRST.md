# 知芽 Web 设计交接包

先阅读 Docs/05-technical-design/TreeLearn_Web本地版_AI开发交接入口.md。

本包用于设计 review 与开发交接，须配合 Treelearn 源码仓库和 AGENTS.md 使用。HTML 可离线打开；正式 Web 服务仍需开发。

已确认：两端不同步、A 专注阅读默认、薄荷雾面配色、v1.1 图标。
